@extends('layouts.app')
<style>
 .form-control {
  padding-left: 1%;
  width: 27%;
}
   .name{
       margin-left: -59px !important;
   }
   .flag{
       margin-left: -3% !important;
   }
   .form-control.step{
       margin-left: -67px !important;
   }
   .form-control.level{
       margin-left: -67px !important;
   }
    @media (max-width: 400px) { 
        .form-row {
            width: 800px !important;
        }
          .form-control.text-center {
            width: 37% !important;
          }
        
    }
    @media (min-width:1000px) { 
        .zmdi.zmdi-menu{
            margin-top: -16px;
        }
         .m-2.text-center.form-control {
        margin-left: 15% !important;
      }
      .m-6.text-center.form-control {
        margin-left: 6% !important;
      }
        .page-wrapper{
            min-height:1020px !important;
        }
    }
    @media (max-width:578px) { 
        .form-row{
            width: 836px !important;
        }
        .zmdi.zmdi-menu{
            margin-left: 26px;
            margin-top: 26px;
        }
        .btn.btn-primary{
        margin-left: 3%;
        }
        .m-1 {
        margin-left: 1% !important;
        }
        .m-2 {
        margin-left: 5% !important;
        }
        .m-233{
        margin-left: 2% !important;
        }
        .form-control.text-center{
            width:40%;
        }
        .form-group label{
        padding-right: 7%;
        }
    }
</style>
@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Create Country</div>

                    <div class="card-body">
                        <form method="POST" action="{{ route('country.store')}}">
                            @csrf
                            <div class="form-group">
                                <label for="name">Country Name</label>
                                <input id="name" type="text" class="name form-control" placeholder="Name" name="name" value="{{ old('name') }}" required autofocus>
                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label for="flag">Country Flag</label>
                                <input id="flag" type="text" class="flag form-control" placeholder="Country Flag" name="flag" value="{{ old('flag') }}">
                                @error('flag')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>

                            <div class="form-group step">
                                <label for="steps">Business Step</label>
                                    <input id="step_0" type="text" class="step form-control" value="{{ old('steps[0]') }}" name="steps[]" placeholder="Step Name">
                            </div>
                            <div class="form-group level">
                                <label for="levels">Business Level</label>
                                <input id="level_0" type="number" class="level form-control" value="{{ old('levels[0]') }}" name="levels[]" placeholder="Step Level" required>
                            </div>
                                <div id="business_steps">
                                    
                                </div>
                                <button type="button" class="btn btn-success" id="add_step">Add Step</button>

                            <button type="submit" class="btn btn-primary">Create</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

   <script>
        document.addEventListener('DOMContentLoaded', function() {
            let stepCount = 2;
            document.getElementById('add_step').addEventListener('click', function() {
                var stepDiv = document.createElement('div');
                stepDiv.classList.add('appendedrow');
                stepDiv.innerHTML = `
                    <div class="form-group step">
                        <label for="step_${stepCount}">Business Step ${stepCount}</label>
                        <input id="step_${stepCount}" type="text" class="step form-control" name="steps[]" placeholder="Step Name ${stepCount}">
                        <button type="button" class="btn btn-danger delete-step-level">Delete</button>
                    </div>
                    <div class="form-group level">
                        <label for="level_${stepCount}">Business Level ${stepCount}</label>
                        <input id="level_${stepCount}" type="number" class="level form-control" name="levels[]" placeholder="Step Level ${stepCount}">
                    </div>
                `;
                document.getElementById('business_steps').appendChild(stepDiv);
                stepCount++;
            });
              document.addEventListener('click', function(event) {
                if (event.target.classList.contains('delete-step-level')) {
                    event.target.closest('.appendedrow').remove();
                    stepCount--;
                }
            });
        });
    </script>
@endsection

