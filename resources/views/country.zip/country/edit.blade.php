@extends('layouts.app')
<style>
.btn.btn-danger{
    margin-left: 10px !important;
}
.form-control {
  padding-left: 1%;
  width: 27%;
}
   .name{
       margin-left: -59px !important;
   }
   .flag{
       margin-left: -3% !important;
   }
   .form-control.step{
       margin-left: -67px !important;
   }
   .form-control.level{
       margin-left: -67px !important;
   }
    @media (max-width: 400px) { 
        .form-row {
            width: 800px !important;
        }
        
    }
    @media (min-width:1000px) { 
        .zmdi.zmdi-menu{
            margin-top: -16px;
        }
         .m-2.text-center.form-control {
        margin-left: 15% !important;
      }
      .m-6.text-center.form-control {
        margin-left: 6% !important;
      }
        .page-wrapper{
            min-height:1020px !important;
        }
    }
    @media (max-width:578px) { 
        .form-row{
            width: 836px !important;
        }
        .zmdi.zmdi-menu{
            margin-left: 26px;
            margin-top: 26px;
        }
        .m-1 {
        margin-left: 1% !important;
        }
        .m-2 {
        margin-left: 5% !important;
        }
        .m-233{
        margin-left: 2% !important;
        }
        .form-control.text-center{
            width:40% !important;
        }
        .form-group label{
        padding-right: 7%;
        }
    }
</style>
@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Update Country</div>

                    <div class="card-body">
                        <form method="POST" action="{{ route('country.update', $country->id) }}">
                            @csrf
                            @method('PUT')
                            <div class="form-group">
                                <label for="name">Country Name</label>
                                <input id="name" type="text" class="name form-control" placeholder="Name" name="name" value="{{ $country->name }}" required autofocus>
                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label for="flag">Country Flag</label>
                                <input id="flag" type="text" class="flag form-control" placeholder="Country Flag" name="flag" value="{{ $country->flag }}">
                                @error('flag')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>

                            <div id="business_steps">
                                @foreach($country->steps as $index => $step)
                                        @if ($index > 0)
                                           <div class="appendedrow">
                                        @endif
                                    <div class="form-group step">
                                        <label for="step_{{ $index }}">Business Step {{ $index + 1 }}</label>
                                        <input id="step_{{ $index }}" type="text" class="step form-control" name="steps[]" placeholder="Step Name" value="{{ $step->name }}">
                                        @if ($index > 0)
                                            <button type="button" class="btn btn-danger delete-step-level">Delete</button>
                                        @endif
                                    </div>
                                    <div class="form-group level">
                                        <label for="level_{{ $index }}">Business Level {{ $index + 1 }}</label>
                                        <input id="level_{{ $index }}" type="number" class="level form-control" name="levels[]" placeholder="Step Level" value="{{ $step->level }}">
                                       
                                    </div>
                                    @if ($index > 0)
                                           </div>
                                        @endif
                                @endforeach
                            </div>
                            <button type="button" class="btn btn-success" id="add_step">Add Step</button>

                            <button type="submit" class="btn btn-primary">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let stepCount = {{ count($country->steps) + 1 }};
            document.getElementById('add_step').addEventListener('click', function() {
                var stepDiv = document.createElement('div');
                stepDiv.classList.add('appendedrow');
                stepDiv.innerHTML = `
                    <div class="form-group step">
                        <label for="step_${stepCount}">Business Step ${stepCount}</label>
                        <input id="step_${stepCount}" type="text" class="step form-control" name="steps[]" placeholder="Step Name">
                        <button type="button" class="btn btn-danger delete-step-level">Delete</button>
                    </div>
                    <div class="form-group level">
                        <label for="level_${stepCount}">Business Level ${stepCount}</label>
                        <input id="level_${stepCount}" type="number" class="level form-control" name="levels[]" placeholder="Step Level">
                    </div>
                `;
                document.getElementById('business_steps').appendChild(stepDiv);
                stepCount++;
            });
            document.addEventListener('click', function(event) {
                if (event.target.classList.contains('delete-step-level')) {
                    event.target.closest('.appendedrow').remove();
                    stepCount--;
                }
            });
        });
    </script>
@endsection
